export interface StudentResult {
  rNo: number;
  name: string;
  nahv: number;
  motivation: number;
  thajweed: number;
  fiqh: number;
  sarf: number;
  english: number;
  it: number;
  doura: number;
  softSkills: number;
  tMark: number;
  percentage: number;
  grade: string;
  cRank: number;
  qualify: 'PASSED' | 'FAILED';
}
