import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Download, Filter, ChevronDown, ChevronUp, GraduationCap, Trophy, AlertCircle, CheckCircle2 } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { studentData } from './data';
import { StudentResult } from './types';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'PASSED' | 'FAILED'>('ALL');
  const [sortConfig, setSortConfig] = useState<{ key: keyof StudentResult; direction: 'asc' | 'desc' } | null>(null);
  const [showTopModal, setShowTopModal] = useState(false);

  const topPerformer = studentData.find(s => s.cRank === 1);

  const filteredData = studentData.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.rNo.toString().includes(searchTerm);
    const matchesFilter = filterType === 'ALL' || student.qualify === filterType;
    return matchesSearch && matchesFilter;
  });

  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortConfig) return 0;
    const { key, direction } = sortConfig;
    if (a[key] < b[key]) return direction === 'asc' ? -1 : 1;
    if (a[key] > b[key]) return direction === 'asc' ? 1 : -1;
    return 0;
  });

  const requestSort = (key: keyof StudentResult) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const handleExportCSV = () => {
    const headers = [
      'Roll No', 'Name', 'Nahv', 'Motivation', 'Thajweed', 'Fiqh', 'Sarf', 
      'English', 'IT', 'Doura', 'Soft Skills', 'Total', 'Percentage', 'Grade', 'Rank', 'Status'
    ];

    const csvRows = sortedData.map(student => [
      student.rNo,
      `"${student.name}"`,
      student.nahv,
      student.motivation,
      student.thajweed,
      student.fiqh,
      student.sarf,
      student.english,
      student.it,
      student.doura,
      student.softSkills,
      student.tMark,
      student.percentage.toFixed(2),
      `"${student.grade}"`,
      student.cRank,
      student.qualify
    ].join(','));

    const csvContent = [headers.join(','), ...csvRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `student_results_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getGradeColor = (grade: string) => {
    if (grade.includes('A+')) return 'text-emerald-600 font-bold';
    if (grade.includes('V(VERY GOOD)')) return 'text-blue-600 font-bold';
    if (grade.includes('B')) return 'text-indigo-600 font-bold';
    if (grade.includes('C')) return 'text-amber-600 font-bold';
    return 'text-rose-600 font-bold';
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-600';
    if (score >= 75) return 'text-blue-600';
    if (score >= 50) return 'text-amber-600';
    return 'text-rose-600 font-bold';
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header Section */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpntvdHGS8c3nh-rEEOW03mhtoC_6AIIPVqQ&s" 
              alt="Logo" 
              className="w-12 h-12 object-contain rounded-xl shadow-lg shadow-indigo-100 bg-white p-1"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-800 uppercase">PLUS ONE STUDENTS RESULTS</h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Academic Performance 2025-26</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
              <input
                type="text"
                placeholder="Search by name or roll no..."
                className="pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl w-72 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button 
              onClick={handleExportCSV}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Download size={18} />
              Export CSV
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { id: 'ALL', label: 'Total Students', value: studentData.length, icon: GraduationCap, color: 'bg-indigo-50 text-indigo-600', activeColor: 'ring-2 ring-indigo-500 bg-indigo-100' },
            { id: 'PASSED', label: 'Passed', value: studentData.filter(s => s.qualify === 'PASSED').length, icon: CheckCircle2, color: 'bg-emerald-50 text-emerald-600', activeColor: 'ring-2 ring-emerald-500 bg-emerald-100' },
            { id: 'FAILED', label: 'Failed', value: studentData.filter(s => s.qualify === 'FAILED').length, icon: AlertCircle, color: 'bg-rose-50 text-rose-600', activeColor: 'ring-2 ring-rose-500 bg-rose-100' },
            { id: 'TOP', label: 'Top Performer', value: studentData.find(s => s.cRank === 1)?.name || 'N/A', icon: Trophy, color: 'bg-amber-50 text-amber-600', activeColor: '' },
          ].map((stat, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={stat.label}
              onClick={() => {
                if (stat.id === 'TOP') {
                  setShowTopModal(true);
                  return;
                }
                setFilterType(stat.id as any);
              }}
              className={cn(
                "bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all cursor-pointer hover:shadow-md",
                filterType === stat.id ? stat.activeColor : "hover:border-slate-300"
              )}
            >
              <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", stat.color)}>
                <stat.icon size={24} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                <p className="text-xl font-bold text-slate-800">{stat.value}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Table Section */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[1200px]">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-200">
                  {[
                    { key: 'rNo', label: 'R.NO', width: 'w-20' },
                    { key: 'name', label: 'STUDENT NAME', width: 'w-64' },
                    { key: 'nahv', label: 'NAHV' },
                    { key: 'motivation', label: 'MOTIVATION' },
                    { key: 'thajweed', label: 'THAJWEED' },
                    { key: 'fiqh', label: 'FIQH' },
                    { key: 'sarf', label: 'SARF' },
                    { key: 'english', label: 'ENGLISH' },
                    { key: 'it', label: 'IT' },
                    { key: 'doura', label: 'DOURA' },
                    { key: 'softSkills', label: 'SOFT & SKILLS' },
                    { key: 'tMark', label: 'TOTAL' },
                    { key: 'percentage', label: '%' },
                    { key: 'grade', label: 'GRADE' },
                    { key: 'cRank', label: 'RANK' },
                    { key: 'qualify', label: 'STATUS' },
                  ].map((col) => (
                    <th 
                      key={col.key}
                      onClick={() => requestSort(col.key as keyof StudentResult)}
                      className={cn(
                        "px-4 py-4 text-[11px] font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:bg-slate-100 transition-colors group",
                        col.width
                      )}
                    >
                      <div className="flex items-center gap-1.5">
                        {col.label}
                        <div className="flex flex-col opacity-0 group-hover:opacity-100 transition-opacity">
                          <ChevronUp size={10} className={cn(sortConfig?.key === col.key && sortConfig.direction === 'asc' ? 'text-indigo-600' : 'text-slate-300')} />
                          <ChevronDown size={10} className={cn(sortConfig?.key === col.key && sortConfig.direction === 'desc' ? 'text-indigo-600' : 'text-slate-300')} />
                        </div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <AnimatePresence mode="popLayout">
                  {sortedData.map((student, idx) => (
                    <motion.tr
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      key={student.rNo}
                      className="hover:bg-slate-50/50 transition-colors group"
                    >
                      <td className="px-4 py-4 text-sm font-mono text-slate-400">{student.rNo}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                            {student.name.charAt(0)}
                          </div>
                          <span className="text-sm font-semibold text-slate-700">{student.name}</span>
                        </div>
                      </td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.nahv))}>{student.nahv}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.motivation))}>{student.motivation}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.thajweed))}>{student.thajweed}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.fiqh))}>{student.fiqh}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.sarf))}>{student.sarf}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.english))}>{student.english}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.it))}>{student.it}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.doura))}>{student.doura}</td>
                      <td className={cn("px-4 py-4 text-sm font-medium", getScoreColor(student.softSkills))}>{student.softSkills}</td>
                      <td className="px-4 py-4 text-sm font-bold text-slate-800">{student.tMark}</td>
                      <td className="px-4 py-4 text-sm font-medium text-slate-600">{student.percentage.toFixed(2)}%</td>
                      <td className={cn("px-4 py-4 text-xs font-bold uppercase", getGradeColor(student.grade))}>{student.grade}</td>
                      <td className="px-4 py-4">
                        <span className={cn(
                          "inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold",
                          student.cRank <= 3 ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"
                        )}>
                          {student.cRank}
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <span className={cn(
                          "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          student.qualify === 'PASSED' 
                            ? "bg-emerald-100 text-emerald-700 border border-emerald-200" 
                            : "bg-rose-100 text-rose-700 border border-rose-200"
                        )}>
                          {student.qualify}
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
          {sortedData.length === 0 && (
            <div className="p-20 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="text-slate-300" size={32} />
              </div>
              <h3 className="text-slate-800 font-bold">No results found</h3>
              <p className="text-slate-500 text-sm">Try searching for a different name or roll number.</p>
            </div>
          )}
        </motion.div>
      </main>

      <footer className="max-w-[1600px] mx-auto px-6 py-12 flex flex-col md:flex-row items-center justify-between gap-6 border-t border-slate-100">
        <div className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">
          &copy; 2026 Academic Excellence Portal • All Rights Reserved
        </div>
        <div className="text-slate-800 text-xs font-black uppercase tracking-[0.3em] flex items-center gap-4">
          <img 
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpntvdHGS8c3nh-rEEOW03mhtoC_6AIIPVqQ&s" 
            alt="Logo" 
            className="w-10 h-10 object-contain rounded-full border border-slate-100 bg-white"
            referrerPolicy="no-referrer"
          />
          AKODE ISLAMIC CENTRE
        </div>
      </footer>

      {/* Top Performer Modal */}
      <AnimatePresence>
        {showTopModal && topPerformer && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowTopModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row border border-white/20"
            >
              {/* Photo Section */}
              <div className="md:w-[45%] h-96 md:h-auto relative">
                <img 
                  src="https://lh3.googleusercontent.com/sitesv/APaQ0SRfoumlz9e2CxrTXpw0wNax8jITgCXNP1JiMIGHj4imZe3jdTLtkfx34BpLM-9UisyVKoxOmwTD1VL3v4esaz9E3826R1iXXqiY7eRY651jLF5hn8hoU0cE_hO09j89Zg2rLLDZ0QmMEuSuU1NRAsY-48ozP_v3lmrxeUDU6bDuwUfpgznWWY50DqwEgwdu9m0sqaoESSg3O8jl40gcfcfwC7LgYryspntptE8=w1280" 
                  alt={topPerformer.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                
                {/* Floating Badge */}
                <div className="absolute top-8 left-8">
                  <div className="bg-white/10 backdrop-blur-md border border-white/20 px-4 py-2 rounded-2xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-amber-400 flex items-center justify-center text-amber-900 shadow-lg shadow-amber-400/20">
                      <Trophy size={16} />
                    </div>
                    <span className="text-white text-xs font-black uppercase tracking-widest">Top Rank</span>
                  </div>
                </div>

                <div className="absolute bottom-10 left-10 right-10 text-white">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="text-5xl font-black tracking-tighter leading-none mb-4 drop-shadow-2xl"
                  >
                    {topPerformer.name}
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.8 }}
                    transition={{ delay: 0.5 }}
                    className="flex items-center gap-4"
                  >
                    <div className="h-px flex-1 bg-white/30" />
                    <span className="text-[10px] font-black uppercase tracking-[0.4em] whitespace-nowrap">Academic Excellence</span>
                    <div className="h-px flex-1 bg-white/30" />
                  </motion.div>
                </div>
              </div>

              {/* Scoreboard Section */}
              <div className="md:w-[55%] p-10 md:p-16 space-y-10 bg-white relative overflow-hidden">
                {/* Decorative background element */}
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-50 rounded-full blur-3xl opacity-50" />
                
                <div className="relative flex justify-between items-end">
                  <div>
                    <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mb-3">Grand Total</h3>
                    <div className="flex items-baseline gap-2">
                      <span className="text-6xl font-black text-slate-900 tracking-tighter">{topPerformer.tMark}</span>
                      <span className="text-slate-300 text-2xl font-bold">/ 900</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="w-20 h-20 rounded-3xl bg-indigo-600 flex flex-col items-center justify-center text-white shadow-xl shadow-indigo-200">
                      <span className="text-2xl font-black leading-none">{topPerformer.percentage.toFixed(0)}</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest opacity-80">%</span>
                    </div>
                  </div>
                </div>

                <div className="relative grid grid-cols-2 sm:grid-cols-3 gap-6">
                  {[
                    { label: 'Nahv', score: topPerformer.nahv },
                    { label: 'Motivation', score: topPerformer.motivation },
                    { label: 'Thajweed', score: topPerformer.thajweed },
                    { label: 'Fiqh', score: topPerformer.fiqh },
                    { label: 'Sarf', score: topPerformer.sarf },
                    { label: 'English', score: topPerformer.english },
                    { label: 'IT', score: topPerformer.it },
                    { label: 'Doura', score: topPerformer.doura },
                    { label: 'Soft Skills', score: topPerformer.softSkills },
                  ].map((subject, idx) => (
                    <motion.div 
                      key={subject.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.4 + (idx * 0.05) }}
                      className="group"
                    >
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 group-hover:text-indigo-500 transition-colors">{subject.label}</p>
                      <div className="flex items-center gap-3">
                        <span className={cn("text-xl font-black tracking-tight", getScoreColor(subject.score))}>
                          {subject.score}
                        </span>
                        <div className="flex-1 h-1 bg-slate-100 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${subject.score}%` }}
                            transition={{ duration: 1, delay: 0.6 + (idx * 0.05) }}
                            className={cn("h-full rounded-full", getScoreColor(subject.score).replace('text-', 'bg-'))} 
                          />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="relative pt-10 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100">
                      <CheckCircle2 size={24} />
                    </div>
                    <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Final Result</p>
                      <p className="text-lg font-black text-emerald-600 uppercase tracking-widest leading-none mt-1">{topPerformer.qualify}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-4">
                    <div className="text-[9px] font-black text-slate-300 uppercase tracking-[0.3em] flex items-center gap-2">
                      <img 
                        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpntvdHGS8c3nh-rEEOW03mhtoC_6AIIPVqQ&s" 
                        alt="Logo" 
                        className="w-6 h-6 object-contain rounded-full opacity-40 grayscale"
                        referrerPolicy="no-referrer"
                      />
                      AKODE ISLAMIC CENTRE
                    </div>
                    <button 
                      onClick={() => setShowTopModal(false)}
                      className="group relative px-10 py-4 bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-indigo-600 transition-all shadow-2xl shadow-slate-200 overflow-hidden"
                    >
                      <span className="relative z-10">Dismiss</span>
                      <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-violet-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
